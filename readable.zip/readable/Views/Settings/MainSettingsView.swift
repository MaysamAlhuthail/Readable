//
//  MainSettingsView.swift
//  readable page
//
//  Created by Najd Alsabi on 09/06/1447 AH.
//
